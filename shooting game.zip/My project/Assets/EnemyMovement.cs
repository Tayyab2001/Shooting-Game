using UnityEngine;

public class EnemyMovement : MonoBehaviour
{
    public float speed = 2f;

    void Update()
    {
        // Move the enemy downward
        Vector3 pos = transform.position;
        pos.y -= speed * Time.deltaTime;
        transform.position = pos;

        // Destroy enemy if it moves off-screen
        if (pos.y < -Camera.main.orthographicSize - 1)
        {
            Destroy(gameObject);
        }
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("PlayerBullet"))
        {
            Destroy(gameObject); // Destroy enemy
            Destroy(collision.gameObject); // Destroy the bullet
        }
    }
}
